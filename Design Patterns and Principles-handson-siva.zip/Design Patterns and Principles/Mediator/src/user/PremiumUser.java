package user;

public class PremiumUser implements IUser{
	
	private String name;
	
	@Override
	public void sendMessage(String m) {
		
		c.sendMessage(m, name);
	}


	@Override
	public void receiveMessage(String m, String name) {
		
		System.out.println(this.name+" received the message: "+m+" from "+name);
	}
	

	public PremiumUser()
	{
		
	}

	public PremiumUser(String name) {
		this.name = name;
	}


}
