package application;

import mediator.ChatMediator;
import user.BasicUser;
import user.IUser;
import user.PremiumUser;

public class Main {

	public static void main(String[] args) {
		
		//Dummy receiver
		IUser u1=new PremiumUser("User A");
		IUser u2=new BasicUser("User B");
		IUser u3=new PremiumUser("User C");
		
		//ChatBOX
		ChatMediator c=new ChatMediator();
		
		//User added to ChatBOX
		c.addUser(u1);
		c.addUser(u2);
		c.addUser(u3);
		
		//Dummy sender
		IUser u4=new PremiumUser("SENDER");
		
		u4.sendMessage("Hello Everyone!");

	}

}
