package mediator;


import java.util.ArrayList;
import java.util.List;

import user.IUser;

public class ChatMediator implements IChatMediator {
	
	private static List<IUser> users=new ArrayList<> ();

	@Override
	public void addUser(IUser u) {
		users.add(u);
		
	}

	@Override
	public void sendMessage(String m,String name) {
		
		for(IUser u:users)
			u.receiveMessage(m,name);
	}

}
