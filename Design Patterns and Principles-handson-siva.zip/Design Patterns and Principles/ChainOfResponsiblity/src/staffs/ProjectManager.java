package staffs;

import leave.ILeaveRequestHandler;
import leave.LeaveRequest;

public class ProjectManager implements ILeaveRequestHandler {

	ILeaveRequestHandler nextHandler = new HR();

	@Override
	public void Handlerequest(LeaveRequest obj) {
		// TODO Auto-generated method stub
		if (obj.getLeaveDays() >= 3 && obj.getLeaveDays() <= 5)
			System.out.println("Leave is Granted to " + obj.getEmployeeName() + " for " + obj.getLeaveDays()
					+ " by Project Manager");
		else
			nextHandler.Handlerequest(obj);
	}

}
