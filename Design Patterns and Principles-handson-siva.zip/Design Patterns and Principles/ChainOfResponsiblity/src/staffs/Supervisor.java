package staffs;

import leave.ILeaveRequestHandler;
import leave.LeaveRequest;

public class Supervisor implements ILeaveRequestHandler {

	ILeaveRequestHandler nextHandler = new ProjectManager();

	@Override
	public void Handlerequest(LeaveRequest obj) {
		// TODO Auto-generated method stub
		if (obj.getLeaveDays() >= 1 && obj.getLeaveDays() <= 3)
			System.out.println(
					"Leave is Granted to " + obj.getEmployeeName() + " for " + obj.getLeaveDays() + " by Supervisor");
		else
			nextHandler.Handlerequest(obj);
	}
}
