package leave;

public interface ILeaveRequestHandler {

	ILeaveRequestHandler nextHandler = null;

	void Handlerequest(LeaveRequest obj);

}
