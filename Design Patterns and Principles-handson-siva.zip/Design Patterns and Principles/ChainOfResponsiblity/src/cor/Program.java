package cor;

import java.util.Scanner;

import leave.ILeaveRequestHandler;
import leave.LeaveRequest;
import staffs.Supervisor;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LeaveRequest obj = new LeaveRequest();
		Scanner s = new Scanner(System.in);
		obj.setEmployeeName("abc");
		System.out.println("Enter the number of Days for Leave");
		obj.setLeaveDays(s.nextInt());

		ILeaveRequestHandler object = new Supervisor();
		object.Handlerequest(obj);
	}

}
