package interfacesegregate;

import process.ProcessAccessoryRepair;
import process.ProcessOrder;
import process.ProcessPhoneRepair;

public class Implementation implements ProcessOrder, ProcessAccessoryRepair, ProcessPhoneRepair {

	@Override
	public void processOrder() {
		System.out.println("Processing Order");
	}

	@Override
	public void processAccessoryRepair() {
		System.out.println("Repair Type: Accessory");
	}

	@Override
	public void processPhoneRepair() {
		System.out.println("Repair Type: Phone");
	}

}
