package interfacesegregate;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the type");
		String str = s.next();

		Implementation obj = new Implementation();

		switch (str) {
		case "order":
			obj.processOrder();
			break;
		case "phone":
			obj.processPhoneRepair();
			break;
		case "accessory":
			obj.processAccessoryRepair();
			break;
		}
	}

}
