package process;

public interface ProcessAccessoryRepair {

	public void processAccessoryRepair();
}
