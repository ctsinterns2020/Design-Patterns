package process;

public interface ProcessOrder {

	public void processOrder();
}
