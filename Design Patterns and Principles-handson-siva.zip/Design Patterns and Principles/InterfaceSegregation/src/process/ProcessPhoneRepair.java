package process;

public interface ProcessPhoneRepair {

	public void processPhoneRepair();
}
