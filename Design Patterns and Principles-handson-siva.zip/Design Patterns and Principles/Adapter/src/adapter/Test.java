package adapter;

import movable.BugattiVeyron;
import movable.Movable;
import movable.MovableAdapter;
import movable.MovableAdapterImpl;

public class Test {

	public static void main(String[] args) {
		Movable bugattiVeyron = new BugattiVeyron();
		MovableAdapter bugattiVeyronAdapter = new MovableAdapterImpl(bugattiVeyron);

		System.out.println(bugattiVeyronAdapter.getSpeed());
		System.out.print(bugattiVeyronAdapter.getPrice());
	}
}
