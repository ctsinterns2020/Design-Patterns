package movable;

public class MovableAdapterImpl implements MovableAdapter {
	private Movable luxuryCars;

	@Override
	public double getSpeed() {
		return convertMPHtoKMPH(luxuryCars.getSpeed());
	}

	private double convertMPHtoKMPH(double mph) {
		return mph * 1.60934;
	}

	public MovableAdapterImpl(Movable obj) {
		luxuryCars = obj;
	}

	@Override
	public double getPrice() {

		return convertPrice(luxuryCars.getPrice());
	}

	private double convertPrice(double mph) {
		return mph * 0.93;
	}
}