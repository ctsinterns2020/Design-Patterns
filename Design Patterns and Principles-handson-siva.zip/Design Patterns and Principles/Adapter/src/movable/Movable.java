package movable;

public interface Movable { 
	double getSpeed();

	double getPrice();
}