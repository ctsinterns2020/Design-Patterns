package implementation;

import interfaces.ProcessPhoneRepair;

public class IProcessPhoneRepair implements ProcessPhoneRepair{

	@Override
	public void processPhoneRepair() {
		System.out.println("Repair Type: Phone");
	}

}
