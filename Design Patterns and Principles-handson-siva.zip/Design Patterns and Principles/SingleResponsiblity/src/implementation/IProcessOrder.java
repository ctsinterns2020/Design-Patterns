package implementation;

import interfaces.ProcessOrder;

public class IProcessOrder implements ProcessOrder{

	@Override
	public void processOrder() {
		System.out.println("Processing Order");
	}

}
