package implementation;

import interfaces.ProcessAccessoryRepair;

public class IProcessAccessoryRepair implements ProcessAccessoryRepair {

	@Override
	public void processAccessoryRepair() {
		System.out.println("Repair Type: Accessory");
	}

}
