package singleresp;

import java.util.Scanner;

import implementation.IProcessAccessoryRepair;
import implementation.IProcessOrder;
import implementation.IProcessPhoneRepair;
import interfaces.ProcessAccessoryRepair;
import interfaces.ProcessOrder;
import interfaces.ProcessPhoneRepair;

public class MainClass {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter the type");
		String str = s.next();

		ProcessOrder obj = new IProcessOrder();
		ProcessPhoneRepair obj1 = new IProcessPhoneRepair();
		ProcessAccessoryRepair obj2 = new IProcessAccessoryRepair();

		switch (str) {
		case "order":
			obj.processOrder();
			break;
		case "phone":
			obj1.processPhoneRepair();
			break;
		case "accessory":
			obj2.processAccessoryRepair();
			break;
		}
		s.close();
	}

}
