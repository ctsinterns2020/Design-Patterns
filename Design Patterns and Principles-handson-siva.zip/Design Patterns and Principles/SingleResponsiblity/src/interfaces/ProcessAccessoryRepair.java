package interfaces;

public interface ProcessAccessoryRepair {
	
	public void processAccessoryRepair();
}
