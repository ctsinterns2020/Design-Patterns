package interfaces;

public interface ProcessOrder {

	public void processOrder();
}
