package interfaces;

public interface ProcessPhoneRepair {

	public void processPhoneRepair();
}
