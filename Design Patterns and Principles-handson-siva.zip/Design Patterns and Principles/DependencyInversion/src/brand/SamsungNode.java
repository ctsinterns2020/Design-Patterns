package brand;

public class SamsungNode implements Iphone
{

	@Override
	public void GetName() {
		// TODO Auto-generated method stub
		System.out.println("SamsungNode Mobile");
	}

	@Override
	public void GetPrice() {
		// TODO Auto-generated method stub
		System.out.println("Rs.20,000");
	}

}
