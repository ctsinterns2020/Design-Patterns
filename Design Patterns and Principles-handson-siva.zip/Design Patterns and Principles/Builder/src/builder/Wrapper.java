package builder;

import model.Packing;

public class Wrapper implements Packing {

	@Override

	public String pack() {

		return "Wrapper";

	}

}