package Audi;

import mercedes.Headlights;

public class AudiHeadlights implements Headlights{

	@Override
	public void display() {
		System.out.println("Headlights of Audi");
	}

	
}
