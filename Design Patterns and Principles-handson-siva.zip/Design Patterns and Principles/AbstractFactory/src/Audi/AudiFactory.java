package Audi;

import factory.Factory;
import mercedes.Headlights;
import mercedes.Tire;

public class AudiFactory implements Factory {

	@Override
	public Headlights makeheadlights() {
		// TODO Auto-generated method stub

		return new AudiHeadlights();
	}

	@Override
	public Tire makeTire() {
		// TODO Auto-generated method stub
		return new AudiTire();
	}

}
