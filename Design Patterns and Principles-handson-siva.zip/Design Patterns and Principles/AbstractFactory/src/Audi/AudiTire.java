package Audi;

import mercedes.Tire;

public class AudiTire implements Tire{

	@Override
	public void details() {
		System.out.println("Tire for Audi");
	}

}
