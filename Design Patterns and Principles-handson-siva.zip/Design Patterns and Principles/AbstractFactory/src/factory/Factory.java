package factory;

import mercedes.Headlights;
import mercedes.Tire;

public interface Factory {

	Headlights makeheadlights();

	Tire makeTire();
}
