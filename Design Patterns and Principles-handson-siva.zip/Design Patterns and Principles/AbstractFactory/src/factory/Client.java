package factory;

import Audi.AudiFactory;
import mercedes.Headlights;
import mercedes.MercedesFactory;
import mercedes.Tire;

public class Client {

	public static void main(String[] args) {
		Factory obj = new AudiFactory();
		Headlights light = obj.makeheadlights();
		light.display();

		Tire tire = obj.makeTire();
		tire.details();

		new MercedesFactory().makeheadlights().display();

		new MercedesFactory().makeTire().details();
	}

}
