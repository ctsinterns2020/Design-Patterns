package mercedes;

public interface Headlights {

	 void display();
}
