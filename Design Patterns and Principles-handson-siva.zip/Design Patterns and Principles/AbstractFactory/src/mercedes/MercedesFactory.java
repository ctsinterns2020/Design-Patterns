package mercedes;

import factory.Factory;

public class MercedesFactory implements Factory{

	@Override
	public Headlights makeheadlights() {
		
		return new MercedesHeadlights();
	}

	@Override
	public Tire makeTire() {
		return new MercedesTire();
	}

}
