package mercedes;

public class MercedesTire implements Tire{

	@Override
	public void details() {
		System.out.println("Tire for Mercedes");
	}
}
