package mercedes;

public interface Tire {

	void details();
}
