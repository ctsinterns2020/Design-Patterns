package mercedes;

public class MercedesHeadlights implements Headlights{

	@Override
	public void display() {
		System.out.println("Headlights of Mercedes");
	}

	

}
