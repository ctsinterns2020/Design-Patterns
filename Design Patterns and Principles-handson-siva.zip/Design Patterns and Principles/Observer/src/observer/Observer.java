package observer;

import message.Message;

public interface Observer

{
	public void update(Message m);

}