package facadeclass;

import java.util.ArrayList;
import java.util.List;

import model.Circle;
import model.Rectangle;
import model.Shape;
import model.Square;

public class ShapeMaker {
	
	private Shape circle;
	private Shape rectangle;
	private Shape square;
	

	public ShapeMaker() {
		
	}
	
	public void drawCircle()
	{
		circle=new Circle();
		circle.draw();
		
	}
	
	public void drawRectangle()
	{
		rectangle=new Rectangle();
		rectangle.draw();
	}

	public void drawSquare()
	{
		square=new Square();
		square.draw();
	}
	
	//Future use
	private static List<Shape> shapes=new ArrayList<>();
	
	public void addShape(Shape s)
	{
		shapes.add(s);
	}
	
	public void draw(Shape s)
	{
		s.draw();
	}
	
	public void drawAll()
	{
		for(Shape s:shapes)
		{
			s.draw();
		}
	}
}
