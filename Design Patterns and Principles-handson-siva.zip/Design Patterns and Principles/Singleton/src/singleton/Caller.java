package singleton;

public class Caller {

	public static void main(String[] args) {
		
		DBConn object1 = DBConn.getInstance();
		DBConn object2 = DBConn.getInstance();

		if (object1 == object2) {

			System.out.println("Both objects are same");
		}

	}

}
