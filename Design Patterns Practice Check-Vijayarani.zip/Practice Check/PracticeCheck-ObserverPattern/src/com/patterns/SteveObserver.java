package com.patterns;

public class SteveObserver implements INotificationObserver{

	String name="Steve";
	@Override
	public void OnServerDown() {
		// TODO Auto-generated method stub
		System.out.println(name+" received the Notification");
	}

}
