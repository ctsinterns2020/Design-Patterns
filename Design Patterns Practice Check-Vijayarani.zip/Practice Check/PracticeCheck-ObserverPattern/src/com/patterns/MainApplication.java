package com.patterns;

public class MainApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		INotificationObserver john=new JohnObserver();
		INotificationObserver steve=new SteveObserver();
		
		NotificationService obj=new NotificationService();
		
		obj.AddSubscriber(john);
		obj.AddSubscriber(steve);
		
		obj.NotifySubscriber();
		
		System.out.println();
		obj.RemoveSubscriber(steve);
		
		obj.NotifySubscriber();
		
	}

}
