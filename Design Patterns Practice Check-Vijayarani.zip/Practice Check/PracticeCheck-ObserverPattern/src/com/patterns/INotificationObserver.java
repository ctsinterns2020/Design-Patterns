package com.patterns;

public interface INotificationObserver {

	String name="";
	
	void OnServerDown();
	
}
