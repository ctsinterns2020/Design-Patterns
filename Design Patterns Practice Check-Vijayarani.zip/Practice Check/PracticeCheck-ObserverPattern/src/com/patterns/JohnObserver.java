package com.patterns;

public class JohnObserver implements INotificationObserver{

	String name="John";
	@Override
	public void OnServerDown() {
		// TODO Auto-generated method stub
		System.out.println(name+" received the Notification");
	}

}
