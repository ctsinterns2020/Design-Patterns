package com.patterns;

import java.util.ArrayList;
import java.util.List;

public class NotificationService implements INotificationService{

	List<INotificationObserver> li=new ArrayList<INotificationObserver>();
	
	@Override
	public void AddSubscriber(INotificationObserver obj) {
		// TODO Auto-generated method stub
		li.add(obj);
	//	System.out.println(li);
	}

	@Override
	public void RemoveSubscriber(INotificationObserver obj) {
		// TODO Auto-generated method stub
		li.remove(obj);
	//	System.out.println(li);
	}

	@Override
	public void NotifySubscriber() {
		// TODO Auto-generated method stub
		for(INotificationObserver object:li)
			object.OnServerDown();
	}

	

}
