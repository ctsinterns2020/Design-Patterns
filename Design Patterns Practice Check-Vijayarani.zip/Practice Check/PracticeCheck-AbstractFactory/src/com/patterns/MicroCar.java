package com.patterns;

public class MicroCar extends Car{

	MicroCar(Location location)
	{
		super(CarType.MICRO,location);
		construct(location);
	}
	
	
	@Override
	void construct(Location location) {
		// TODO Auto-generated method stub
	System.out.println("Connecting to Micro Car in location "+location);
	}

}
