package com.patterns;

public class CarClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CarFactory obj=new CarFactory();
		
		obj.buildCar(CarType.LUXURY,Location.USA);
		obj.buildCar(CarType.MICRO,Location.USA);
		obj.buildCar(CarType.MINI,Location.INDIA);
		obj.buildCar(CarType.LUXURY,Location.DEFAULT);
	}

}
