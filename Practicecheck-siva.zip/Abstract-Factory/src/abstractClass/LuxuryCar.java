package abstractClass;




public class LuxuryCar extends Car{

	LuxuryCar(Location location)
	{
		super(CarType.LUXURY,location);
		construct(location);
	}
	
	
	@Override
	void construct(Location location) {
		// TODO Auto-generated method stub
	System.out.println("Connecting to Luxury Car in location "+location);
	}

}
