package abstractClass;

public class MiniCar extends Car{

	MiniCar(Location location)
	{
		super(CarType.MINI,location);
		construct(location);
	}
	
	
	@Override
	void construct(Location location) {
		// TODO Auto-generated method stub
	System.out.println("Connecting to Mini Car in Location "+location);
	}

}
