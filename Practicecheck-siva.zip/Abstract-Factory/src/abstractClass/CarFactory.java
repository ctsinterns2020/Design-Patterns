package abstractClass;





public class CarFactory {

	void buildCar(CarType model,Location location)
	{
		
		if(model.equals(CarType.LUXURY))
		{
		  Car obj=new LuxuryCar(location);
			}
		else if(model.equals(CarType.MICRO))
		{
			Car obj=new MicroCar(location);
		}
		else
		{
			Car obj=new MiniCar(location);
		}
	}
	
	
}
