package interfaces;

public interface INotificationObserver {

	String name="";
	
	void OnServerDown();
	
}
