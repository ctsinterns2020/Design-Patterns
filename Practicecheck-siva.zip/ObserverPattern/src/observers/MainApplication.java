package observers;

import interfaces.INotificationObserver;

public class MainApplication {

	public static void main(String[] args) {
		INotificationObserver john=new AjithObserver();
		INotificationObserver steve=new DhoniObserver();
		
		NotificationService obj=new NotificationService();
		
		obj.AddSubscriber(john);
		obj.AddSubscriber(steve);
		
		obj.NotifySubscriber();
		
		System.out.println();
		obj.RemoveSubscriber(steve);
		
		obj.NotifySubscriber();
		
	}

}
