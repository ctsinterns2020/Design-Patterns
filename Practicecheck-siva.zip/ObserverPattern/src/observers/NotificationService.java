package observers;

import java.util.ArrayList;
import java.util.List;

import interfaces.INotificationObserver;
import interfaces.INotificationService;

public class NotificationService implements INotificationService{

	List<INotificationObserver> li=new ArrayList<INotificationObserver>();
	
	@Override
	public void AddSubscriber(INotificationObserver obj) {
	
		li.add(obj);
	}

	@Override
	public void RemoveSubscriber(INotificationObserver obj) {
		li.remove(obj);

	}

	@Override
	public void NotifySubscriber() {
		for(INotificationObserver object:li)
			object.OnServerDown();
	}

	

}
