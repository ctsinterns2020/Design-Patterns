package observers;

import interfaces.INotificationObserver;

public class AjithObserver implements INotificationObserver{

	String name="Ajith";
	@Override
	public void OnServerDown() {
	
		System.out.println(name+" received the Notification");
	}

}
