package observers;

import interfaces.INotificationObserver;

public class DhoniObserver implements INotificationObserver{

	String name="Dhoni";
	@Override
	public void OnServerDown() {
		System.out.println(name+" received the Notification");
	}

}
