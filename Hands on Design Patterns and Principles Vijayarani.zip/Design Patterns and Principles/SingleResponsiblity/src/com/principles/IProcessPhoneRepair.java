package com.principles;

public class IProcessPhoneRepair implements ProcessPhoneRepair{

	@Override
	public void processPhoneRepair() {
		// TODO Auto-generated method stub
		System.out.println("Repair Type: Phone");
	}

}
