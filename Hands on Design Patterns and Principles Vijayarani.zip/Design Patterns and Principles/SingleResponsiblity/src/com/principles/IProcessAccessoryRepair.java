package com.principles;

public class IProcessAccessoryRepair implements ProcessAccessoryRepair {

	@Override
	public void processAccessoryRepair() {
		// TODO Auto-generated method stub
		System.out.println("Repair Type: Accessory");
	}

}
