package com.principles;

public class IProcessOrder implements ProcessOrder{

	@Override
	public void processOrder() {
		// TODO Auto-generated method stub
		System.out.println("Processing Order");
	}

}
