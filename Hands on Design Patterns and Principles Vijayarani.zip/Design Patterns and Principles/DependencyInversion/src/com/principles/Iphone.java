package com.principles;

public interface Iphone {

	public void GetName();
	public void GetPrice();
	
	
}
