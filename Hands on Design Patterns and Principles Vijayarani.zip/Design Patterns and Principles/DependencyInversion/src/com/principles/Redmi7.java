package com.principles;

public class Redmi7 implements Iphone{

	@Override
	public void GetName() {
		// TODO Auto-generated method stub
		System.out.println("Redmi Mobile");

	}

	@Override
	public void GetPrice() {
		// TODO Auto-generated method stub
		System.out.println("Rs.12,000");

	}

}
