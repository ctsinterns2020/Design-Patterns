package com.principles;

public class MainClass {
  public static void main(String[] args)
  {
	  Iphone obj=new SamsungNode();
	  obj.GetName();
	  obj.GetPrice();

	  Iphone obj1=new Redmi7();
	  obj1.GetName();
	  obj1.GetPrice();

  }
}
