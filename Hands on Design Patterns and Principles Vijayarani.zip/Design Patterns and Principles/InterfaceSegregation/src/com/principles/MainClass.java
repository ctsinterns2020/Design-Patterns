package com.principles;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("Enter the type");
String str=s.next();

Implementation obj=new Implementation();

switch(str)
{
case "order":
	obj.processOrder();
	break;
case "phone":
	obj.processPhoneRepair();
	break;
case "accessory":
	obj.processAccessoryRepair();
	break;
}
	}

}
