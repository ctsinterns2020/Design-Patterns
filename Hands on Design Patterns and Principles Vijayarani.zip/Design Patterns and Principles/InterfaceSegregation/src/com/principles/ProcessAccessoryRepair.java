package com.principles;

public interface ProcessAccessoryRepair {
	
	public void processAccessoryRepair();
}
