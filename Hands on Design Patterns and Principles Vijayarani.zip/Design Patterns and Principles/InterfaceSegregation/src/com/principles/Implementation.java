package com.principles;

public class Implementation implements ProcessOrder,ProcessAccessoryRepair,ProcessPhoneRepair{

	@Override
	public void processOrder() {
		// TODO Auto-generated method stub
		System.out.println("Processing Order");
	}
	
	@Override
	public void processAccessoryRepair() {
		// TODO Auto-generated method stub
		System.out.println("Repair Type: Accessory");
	}

	@Override
	public void processPhoneRepair() {
		// TODO Auto-generated method stub
		System.out.println("Repair Type: Phone");
	}

}
