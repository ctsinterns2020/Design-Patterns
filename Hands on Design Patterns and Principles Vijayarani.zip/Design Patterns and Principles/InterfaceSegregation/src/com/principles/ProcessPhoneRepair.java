package com.principles;

public interface ProcessPhoneRepair {

	public void processPhoneRepair();
}
