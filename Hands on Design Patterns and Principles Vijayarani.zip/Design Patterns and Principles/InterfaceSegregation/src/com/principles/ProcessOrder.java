package com.principles;

public interface ProcessOrder {

	public void processOrder();
}
