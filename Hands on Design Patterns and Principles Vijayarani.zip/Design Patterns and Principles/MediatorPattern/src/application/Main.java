package application;

import mediator.ChatMediator;
import user.BasicUser;
import user.IUser;
import user.PremiumUser;

public class Main {

	public static void main(String[] args) {
		
		
		IUser u1=new PremiumUser("User A");
		IUser u2=new BasicUser("User B");
		IUser u3=new PremiumUser("User C");
		
		ChatMediator chat=new ChatMediator();
		
		
		chat.addUser(u1);
		chat.addUser(u2);
		chat.addUser(u3);
		
	
		IUser u4=new PremiumUser("SENDER");
		
		u4.sendMessage("Hello Everyone!");

	}

}
