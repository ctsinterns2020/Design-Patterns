package mediator;

import user.IUser;

public interface IChatMediator {
	
	public void addUser(IUser u);
	
	public void sendMessage(String m,String name);

}
