package user;

import mediator.ChatMediator;

public interface IUser {
	public static final ChatMediator c = new ChatMediator();
	
	public void sendMessage(String m);
	
	public void receiveMessage(String m,String name);


}
