package com.patterns;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBConn object1=DBConn.getInstance();
		DBConn object2=DBConn.getInstance();
		

		if(object1==object2) {
			
			System.out.println("Both objects are same");
		}
		
	}

}
