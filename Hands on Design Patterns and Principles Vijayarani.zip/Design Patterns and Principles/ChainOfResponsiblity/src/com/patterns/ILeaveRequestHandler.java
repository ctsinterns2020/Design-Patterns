package com.patterns;

public interface ILeaveRequestHandler {

	ILeaveRequestHandler nextHandler=null;
	
	void Handlerequest(LeaveRequest obj);
	
}
