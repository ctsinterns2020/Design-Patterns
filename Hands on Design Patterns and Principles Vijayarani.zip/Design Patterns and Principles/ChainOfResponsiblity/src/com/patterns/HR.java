package com.patterns;

public class HR implements ILeaveRequestHandler{

	ILeaveRequestHandler nextHandler;
	@Override
	public void Handlerequest(LeaveRequest obj) {
		// TODO Auto-generated method stub
		if(obj.getLeaveDays()>5)
			System.out.println("Leave is Granted to "+obj.getEmployeeName()+" for "+obj.getLeaveDays()+" by HR");
		
	}

}
