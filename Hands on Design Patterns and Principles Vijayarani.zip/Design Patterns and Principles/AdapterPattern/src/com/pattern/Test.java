package com.pattern;

public class Test {
	
	public static  void main(String[] args) 
	{ Movable bugattiVeyron = new BugattiVeyron(); 
	MovableAdapter bugattiVeyronAdapter = new MovableAdapterImpl(bugattiVeyron); 
	//assertEquals(bugattiVeyronAdapter.getSpeed(), 431.30312, 0.00001); }

	System.out.println(bugattiVeyronAdapter.getSpeed());
	System.out.print(bugattiVeyronAdapter.getPrice());
}
}
