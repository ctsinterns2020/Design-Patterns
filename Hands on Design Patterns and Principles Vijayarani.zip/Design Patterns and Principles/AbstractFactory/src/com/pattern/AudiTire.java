package com.pattern;

public class AudiTire implements Tire{

	@Override
	public void details() {
		// TODO Auto-generated method stub
		System.out.println("Tire for Audi");
	}

}
