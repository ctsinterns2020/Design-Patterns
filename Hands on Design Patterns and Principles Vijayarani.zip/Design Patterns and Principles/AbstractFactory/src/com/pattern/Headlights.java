package com.pattern;

public interface Headlights {

	 void display();
}
