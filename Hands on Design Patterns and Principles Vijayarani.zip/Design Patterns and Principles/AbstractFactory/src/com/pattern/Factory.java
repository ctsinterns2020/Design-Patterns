package com.pattern;

public interface Factory {

	Headlights makeheadlights();
	Tire makeTire();
}
