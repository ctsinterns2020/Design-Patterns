package com.pattern;

public class MercedesFactory implements Factory{

	@Override
	public Headlights makeheadlights() {
		// TODO Auto-generated method stub
		
		return new MercedesHeadlights();
	}

	@Override
	public Tire makeTire() {
		// TODO Auto-generated method stub
		return new MercedesTire();
	}

}
