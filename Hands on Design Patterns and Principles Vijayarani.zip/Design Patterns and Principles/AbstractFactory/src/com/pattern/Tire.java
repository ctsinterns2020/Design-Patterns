package com.pattern;

public interface Tire {

	void details();
}
