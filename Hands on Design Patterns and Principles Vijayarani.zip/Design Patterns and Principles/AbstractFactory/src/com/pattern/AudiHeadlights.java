package com.pattern;

public class AudiHeadlights implements Headlights{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Headlights of Audi");
	}

	
}
