package com.pattern;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Factory obj=new AudiFactory();
Headlights light=obj.makeheadlights();
light.display();

Tire tire=obj.makeTire();
tire.details();

new MercedesFactory().makeheadlights().display();

new MercedesFactory().makeTire().details();
	}

}
