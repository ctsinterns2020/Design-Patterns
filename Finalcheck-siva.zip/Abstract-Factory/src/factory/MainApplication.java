package factory;

public class MainApplication {

	public static void main(String[] args) {

		OrderFactory factory = new OrderFactory();

		factory.buildProduct(ProductType.ELECTRONIC, Channel.WEBSITE);
		factory.buildProduct(ProductType.FURNITURE, Channel.TELECALLER);
		factory.buildProduct(ProductType.TOYS, Channel.WEBSITE);
		factory.buildProduct(ProductType.TOYS, Channel.TELECALLER);
	}

}
