package factory;

public class FurnitureOrder extends Order{

	FurnitureOrder( Channel channel) {
		super(ProductType.FURNITURE, channel);
		processOrder(channel);
	}

	@Override
	void processOrder(Channel channel) {
		System.out.println("Processing Furniture Order through "+channel);
	}
}