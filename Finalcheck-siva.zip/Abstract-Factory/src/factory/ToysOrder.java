package factory;

public class ToysOrder extends Order{

	ToysOrder( Channel channel) {
		super(ProductType.TOYS, channel);
		processOrder(channel);
	}

	@Override
	void processOrder(Channel channel) {
				System.out.println("Processing Toys Order through "+channel);
	}

}
