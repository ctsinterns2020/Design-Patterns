package factory;

enum ProductType{
	ELECTRONIC,FURNITURE,TOYS
}
enum Channel
{
	WEBSITE,TELECALLER
}
public abstract class Order {
	ProductType type=null;
	Channel channel=null;
	
	

	public ProductType getType() {
		return type;
	}

	public void setType(ProductType type) {
		this.type = type;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	Order(ProductType type,Channel channel)
	{
		this.type=type;
		this.channel=channel;
	}
	
	abstract void processOrder(Channel channel);

	@Override
	public String toString() {
		return "Order [type=" + type + ", channel=" + channel + "]";
	}

	}
