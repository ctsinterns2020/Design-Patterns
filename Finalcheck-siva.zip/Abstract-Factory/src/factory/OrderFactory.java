package factory;

public class OrderFactory {

	void buildProduct(ProductType type, Channel channel) {
		Order order;
		if (type.equals(ProductType.ELECTRONIC)) {
			order = new ElectronicOrder(channel);
		} else if (type.equals(ProductType.FURNITURE)) {
			order = new FurnitureOrder(channel);
		} else {
			order = new ToysOrder(channel);
		}
	}
}
