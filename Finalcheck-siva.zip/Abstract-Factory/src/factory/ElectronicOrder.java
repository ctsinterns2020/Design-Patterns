package factory;

public class ElectronicOrder extends Order{

	ElectronicOrder( Channel channel) {
		super(ProductType.ELECTRONIC, channel);
		processOrder(channel);
	}

	@Override
	void processOrder(Channel channel) {
		System.out.println("Processing Electronic Order through "+channel);
	}
}
