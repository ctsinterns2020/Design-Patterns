package interfaces;

public interface INotificationObserver {
	
	void ticketsBooked();
	
}
