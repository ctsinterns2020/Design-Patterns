package observer;

import java.util.ArrayList;
import java.util.List;

import interfaces.INotificationObserver;
import interfaces.INotificationService;

public class NotificationService implements INotificationService{

	List<INotificationObserver> obslist=new ArrayList<INotificationObserver>();
	
	@Override
	public void AddSubscriber(INotificationObserver obj) {
		obslist.add(obj);
	}

	@Override
	public void RemoveSubscriber(INotificationObserver obj) {
		obslist.remove(obj);
	}

	@Override
	public void NotifySubscriber() {
		for(INotificationObserver obs:obslist)
			obs.ticketsBooked();
	}

	

}
