package observer;

import interfaces.INotificationObserver;

public class AdminThree implements INotificationObserver{

	@Override
	public void ticketsBooked() {
		System.out.println("Admin Three received Notification about 100 Ticket Bookings");
	}

}
