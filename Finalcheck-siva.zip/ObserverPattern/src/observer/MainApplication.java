package observer;

import interfaces.INotificationObserver;

public class MainApplication {

	public static void main(String[] args) {
		INotificationObserver a1=new AdminOne();
		INotificationObserver a2=new AdminTwo();
		INotificationObserver a3=new AdminThree();
		
		NotificationService s=new NotificationService();
		s.AddSubscriber(a1);
		s.AddSubscriber(a2);
		s.AddSubscriber(a3);
		s.NotifySubscriber();
		s.RemoveSubscriber(a2);
		s.NotifySubscriber();
		
	}

}
