package observer;

import interfaces.INotificationObserver;

public class AdminTwo implements INotificationObserver{

	@Override
	public void ticketsBooked() {
		System.out.println("Admin Two received Notification about 100 Ticket Bookings");
	}

}
