package com.patterns;

public class ToysOrder extends Order{

	ToysOrder( Channel channel) {
		super(ProductType.TOYS, channel);
		processOrder(channel);
		// TODO Auto-generated constructor stub
	}

	@Override
	void processOrder(Channel channel) {
		// TODO Auto-generated method stub
		System.out.println("Processing Toys Order through "+channel);
	}

}
