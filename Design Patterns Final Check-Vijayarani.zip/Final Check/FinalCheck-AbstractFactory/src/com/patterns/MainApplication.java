package com.patterns;

public class MainApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
OrderFactory obj=new OrderFactory();
		
		obj.buildProduct(ProductType.ELECTRONIC, Channel.WEBSITE);
		obj.buildProduct(ProductType.FURNITURE, Channel.TELECALLER);
		obj.buildProduct(ProductType.TOYS, Channel.WEBSITE);
		obj.buildProduct(ProductType.TOYS, Channel.TELECALLER);
	}

}
