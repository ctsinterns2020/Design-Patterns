package com.patterns;

public class FurnitureOrder extends Order{

	FurnitureOrder( Channel channel) {
		super(ProductType.FURNITURE, channel);
		processOrder(channel);
		// TODO Auto-generated constructor stub
	}

	@Override
	void processOrder(Channel channel) {
		// TODO Auto-generated method stub
		System.out.println("Processing Furniture Order through "+channel);
	}
}