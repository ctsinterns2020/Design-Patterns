package com.patterns;

public class ElectronicOrder extends Order{

	ElectronicOrder( Channel channel) {
		super(ProductType.ELECTRONIC, channel);
		processOrder(channel);
		// TODO Auto-generated constructor stub
	}

	@Override
	void processOrder(Channel channel) {
		// TODO Auto-generated method stub
		System.out.println("Processing Electronic Order through "+channel);
	}
}
