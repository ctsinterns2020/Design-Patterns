package com.patterns;

public class OrderFactory {

	void buildProduct(ProductType type,Channel channel)
	{
		
		if(type.equals(ProductType.ELECTRONIC))
		{
		  Order obj=new ElectronicOrder(channel);
			}
		else if(type.equals(ProductType.FURNITURE))
		{
			  Order obj=new FurnitureOrder(channel);
				}
		else
		{
			Order obj=new ToysOrder(channel);
		}
	}
}
