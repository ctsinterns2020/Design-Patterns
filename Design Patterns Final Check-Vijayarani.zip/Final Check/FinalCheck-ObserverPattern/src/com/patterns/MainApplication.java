package com.patterns;

public class MainApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		INotificationObserver a1=new AdminOne();
		INotificationObserver a2=new AdminTwo();
		INotificationObserver a3=new AdminThree();
		
		NotificationService obj=new NotificationService();
		
		obj.AddSubscriber(a1);
		obj.AddSubscriber(a2);
		obj.AddSubscriber(a3);
		
		obj.NotifySubscriber();
		
		System.out.println();
		obj.RemoveSubscriber(a2);
		
		obj.NotifySubscriber();
		
	}

}
