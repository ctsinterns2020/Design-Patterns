package com.patterns;

public interface INotificationObserver {
	
	void ticketsBooked();
	
}
