package com.patterns;

public class AdminOne implements INotificationObserver{

	@Override
	public void ticketsBooked() {
		// TODO Auto-generated method stub
		System.out.println("Admin One received Notification about 100 Ticket Bookings");
	}

}
