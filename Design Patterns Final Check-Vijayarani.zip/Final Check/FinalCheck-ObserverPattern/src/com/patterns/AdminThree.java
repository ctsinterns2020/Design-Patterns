package com.patterns;

public class AdminThree implements INotificationObserver{

	@Override
	public void ticketsBooked() {
		// TODO Auto-generated method stub
		System.out.println("Admin Three received Notification about 100 Ticket Bookings");
	}

}
